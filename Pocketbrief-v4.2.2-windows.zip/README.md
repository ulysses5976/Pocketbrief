# 口袋句庫 Pocketbrief

按一個快速鍵叫出你的常用句清單，打幾個字母的代碼，整句話就直接輸入到游標所在的位置。

適合需要反覆輸入固定詞句的人，例如書狀裡的當事人稱謂、契約名稱，或是每天下給 AI 的慣用指令。

![叫出清單後打代碼](docs/screenshots/popup.png)

> [English summary below](#english)

---

## 功能特色

- **快速輸入**：在任何程式裡按 `Ctrl` + `` ` ``（可自訂），叫出句庫清單，打代碼就輸出。代碼只對應到一筆時會直接輸出，不必再按 Enter。
- **快速新增**：在任何地方反白一段文字，按 `Ctrl` + `Shift` + `0`，就能直接存成新範本。
- **沒有數量上限**：範本要存幾筆都可以，要裝在幾台電腦都可以。
- **跨電腦同步**：把整個資料夾放在 Google 雲端硬碟、OneDrive、Dropbox 等同步資料夾裡，改一次，每台電腦都跟著更新。
- **資料留在你手上**：範本存在程式旁邊的 CSV 檔，程式完全不連網。
- **外觀可自訂**：清單的字型、字體大小、顏色、寬度、顯示筆數都能調整，並內建 10 種配色主題（含兩款護眼配色）。
- **深色模式**：可跟隨 Windows，或手動切換淺色／深色。
- **多語言介面**：繁體中文、English、日本語、简体中文。
- **CSV 匯入／匯出**：方便從其他工具搬移，或備份到別處。
- **資料保護**：存檔時先寫暫存檔再替換，不會出現只寫一半的檔案；每天第一次修改前，自動備份一份，保留最近 14 天。

| 句庫管理（淺色） | 句庫管理（深色） |
|---|---|
| ![](docs/screenshots/manager-light.png) | ![](docs/screenshots/manager-dark.png) |

![清單外觀設定](docs/screenshots/settings-appearance.png)

---

## 系統需求

- Windows 10 或 Windows 11
- .NET Framework 4.8（Windows 10／11 已內建，不必另外安裝）
- 目前**不支援 macOS 與 Linux**

## 下載與使用

1. 到 [Releases](../../releases) 下載最新版的 zip 檔，解壓縮到任何資料夾（例如雲端硬碟裡的資料夾）。
2. 對 `Pocketbrief.exe` 點兩下。不需要安裝。
3. 右下角系統匣會出現「句」字圖示，代表程式正在執行。

> **Windows 可能跳出「Windows 已保護您的電腦」**
> 因為這個程式沒有付費的數位簽章，第一次執行時 Windows SmartScreen 可能會提醒。請按「其他資訊」→「仍要執行」。
> 原始碼全部公開，不放心的話可以自行編譯（見下方「自行編譯」）。

## 快速上手

| 動作 | 做法 |
|---|---|
| 叫出範本清單 | 在要打字的地方按 `Ctrl` + `` ` ``（`Esc` 下面那顆鍵） |
| 輸出範本 | 打代碼。只對應到一筆時直接輸出；否則用 ↑↓ 選，按 `Enter` 輸出 |
| 取消 | `Esc` |
| 快速新增範本 | 反白一段文字 → 按 `Ctrl` + `Shift` + `0` |
| 管理範本 | 點系統匣的「句」圖示，或在清單裡按 `F2` |
| 設定 | 句庫管理右上角「設定…」，或在系統匣圖示按右鍵 |

**代碼小技巧**：常用的範本，代碼挑鍵盤左側的字母（例如 `a`、`z`、`x`），按完快速鍵後左手就能馬上打到。代碼開頭相同時（例如 `a` 和 `aa`），打 `a` 會先停住，按 `Enter` 就輸出 `a` 那一筆。

**第一次使用**可以先匯入 [`examples/範例句庫.csv`](examples/範例句庫.csv) 試試看（句庫管理 →「匯入 CSV…」）。

## 跨電腦同步

把 `Pocketbrief.exe` 放在雲端同步資料夾裡執行即可。程式會在同一個資料夾建立：

| 檔案 | 內容 |
|---|---|
| `範本.csv` | 你的所有範本 |
| `設定.ini` | 快速鍵、外觀、語言等設定 |
| `備份\` | 每日自動備份（保留 14 天） |

其他電腦等同步完成後，直接執行同一個資料夾裡的 `Pocketbrief.exe` 就好。在一台電腦修改，其他電腦下次叫出清單時就會讀到新內容。

「開機時自動啟動」是每台電腦各自的設定，要在每台電腦的「設定」裡各勾一次。

> 兩台電腦幾乎同時修改時，雲端硬碟可能產生一份衝突副本（檔名多了「(1)」之類），需要手動合併。

## 範本檔格式

`範本.csv` 是 UTF-8 編碼的 CSV，三個欄位依序是「名稱、代碼、內容」，內容可以有多行。

可以用 Excel 開來看，但**不建議用 Excel 編輯後另存**：Excel 會把代碼開頭的 0 去掉、把 `1-2` 轉成日期、把 `=` 開頭的內容當成公式。請在程式的「句庫管理」裡修改。

代碼規則：英文字母、數字或半形符號，最多 20 碼，不分大小寫；不能有空白、中文或 `` ` ``。

## 隱私與安全

- 程式**不會連線到網路**，也沒有任何統計或回報功能。
- 為了把範本「貼」到目前的視窗，程式會暫時借用剪貼簿，約 1 秒後還原成你原本的內容。
- 因為程式會攔截全域快速鍵、模擬 `Ctrl` + `V` 與 `Ctrl` + `C`，少數防毒軟體可能誤判。原始碼全部公開，可以自行檢查或編譯。
- 已知限制：以「系統管理員身分」執行的視窗，Windows 不允許一般程式送出按鍵，所以無法貼進去。

## 自行編譯

不需要 Visual Studio。Windows 內建的 .NET Framework 就有 C# 編譯器：

```bat
build.cmd
```

完成後會產生 `dist\Pocketbrief.exe`。

原始碼結構：

| 檔案 | 內容 |
|---|---|
| `src/Pocketbrief.cs` | 主程式（快速鍵、清單、句庫管理、設定、存檔） |
| `src/Lang.cs` | 介面語言切換與繁簡轉換 |
| `src/LangTable.cs` | 英文、日文翻譯表 |
| `src/Theme.cs` | 深色模式 |

程式以 C# 5 撰寫，使用 .NET Framework 4.x 內建編譯器（`csc.exe`）即可編譯。新增介面文字時，請在程式裡用 `L.T("繁體中文原文")`，並把英文、日文翻譯加進 `LangTable.cs`。

## 常見問題

**Q：可以跟注音或其他中文輸入法一起用嗎？**
可以。叫出清單時，程式會自動切成英數輸入，打代碼不會變成注音。

**Q：快速鍵跟其他程式衝突怎麼辦？**
到「設定」→「快速鍵與行為」，點一下格子，直接按下想用的組合鍵即可。`Ctrl+C`、`Ctrl+V` 這類系統常用組合不能設定。

**Q：可以從其他工具匯入嗎？**
可以匯入 CSV。程式會自動判斷欄位順序、有沒有標題列，以及 UTF-8 或 Big5 編碼。

---

## English

**Pocketbrief** is a lightweight text-snippet tool for Windows. Press a hotkey (`Ctrl` + `` ` `` by default) anywhere to pop up your phrase list, type a short code, and the whole phrase is inserted at the cursor.

- Unlimited snippets, no installation, works offline (no network access at all)
- Quick-add: select text anywhere and press `Ctrl` + `Shift` + `0`
- Sync across computers by keeping the folder in Google Drive / OneDrive / Dropbox
- Customizable list appearance with 10 color themes, dark mode
- UI in Traditional Chinese, English, Japanese and Simplified Chinese
- CSV import / export, atomic saves and daily backups

![](docs/screenshots/manager-en.png)

**Requirements:** Windows 10/11 with .NET Framework 4.8 (built in). Download the zip from [Releases](../../releases), unzip, and run `Pocketbrief.exe`. If Windows SmartScreen warns you (the program is not code-signed), click "More info" → "Run anyway", or build it yourself with `build.cmd`.

Your templates are stored in `範本.csv` and settings in `設定.ini` next to the exe.

---

## 授權 License

[MIT License](LICENSE) © 2026 無名小律師（楊朝淵律師）

本程式以 Vibe Coding 方式，在 AI（Claude Code）協助下開發。
